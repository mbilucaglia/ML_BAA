function [data_struct_out] = HydroCel2TenTen(data_struct)

list_ten_ten=load('./aux_func_IO/list.mat');
list_hydro_cel=
end

